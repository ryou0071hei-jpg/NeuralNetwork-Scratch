from sklearn.datasets import fetch_openml
import numpy as np

class MNISTLoader:
    def __init__(self, num_classes=10):
        self.num_classes = num_classes

    def one_hot(self, y):
        one_hot = np.zeros((len(y), self.num_classes))
        one_hot[np.arange(len(y)), y] = 1
        return one_hot

    def load_data(self):
        mnist = fetch_openml("mnist_784", version=1)

        x = mnist.data.to_numpy()
        y = mnist.target.to_numpy().astype(np.int64)

        # 正規化
        x = x / 255.0

        # One-Hot Encoding
        y = self.one_hot(y)

        # 訓練データ・テストデータ分割
        x_train = x[:6000]
        x_test = x[6000:12000]

        t_train = y[:6000]
        t_test = y[6000:12000]

        return x_train, t_train, x_test, t_test
# def one_hot(y):

#     num_classes = 10

#     one_hot = np.zeros((len(y), num_classes))

#     one_hot[np.arange(len(y)), y] = 1

#     return one_hot


# def load_mnist():

#     mnist = fetch_openml("mnist_784", version=1)

#     x = mnist.data.to_numpy()
#     y = mnist.target.to_numpy().astype(np.int64)

#     x = x / 255.0

#     y = one_hot(y)

#     x_train = x[:60000]
#     x_test  = x[60000:]

#     t_train = y[:60000]
#     t_test  = y[60000:]

#     return x_train, t_train, x_test, t_test

# if __name__ == "__main__":

#     x_train, t_train, x_test, t_test = load_mnist()

#     print(x_train.shape)
#     print(t_train.shape)
#     print(x_test.shape)
#     print(t_test.shape)