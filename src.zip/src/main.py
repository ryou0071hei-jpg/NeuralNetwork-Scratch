from dataset import MNISTLoader
import matplotlib.pyplot as plt
from model import NeuralNetwork, Objective
import numpy as np

# ===================================================
# ⭐️ 基本パラメータ（ベースライン）の設定
# ===================================================
# ループ変数と衝突しないように大文字で固定値を定義します
BASE_LR = 0.1
BASE_EPOCHS = 100

loader = MNISTLoader()
x_train, t_train, x_test, t_test = loader.load_data()

# ===================================================
# 実験1：活性化関数の比較
# ===================================================
print("\n--- 実験1: 活性化関数の比較 ---")
activations = ["sigmoid","relu"]
plt.figure(figsize=(8, 5))

for act in activations:
    model = NeuralNetwork(activation=act)
    loss_list = []

    # 基本のエポック数（BASE_EPOCHS）を使用
    for epoch in range(BASE_EPOCHS):
        y = model.forward(x_train)
        loss = Objective.cross_entropy(y, t_train)
        loss_list.append(loss)
        # 基本の学習率（BASE_LR）を使用
        model.backward(x_train, y, t_train, BASE_LR)
        
    pred = np.argmax(y, axis=1)
    ans = np.argmax(t_train, axis=1)
    acc = np.mean(pred == ans)
    print(f"Activation: {act} -> Final Train Accuracy: {acc:.4f}")
    plt.plot(loss_list, label=f"activation={act}")

plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Activation Comparison")
plt.grid(True)
plt.legend()
plt.show()

# ===================================================
# 実験2：学習率の比較
# ===================================================
print("\n--- 実験2: 学習率の比較 ---")
learning_rates = [0.001, 0.01, 0.1]
plt.figure(figsize=(8, 5))

# ループ変数は通常の 'lr' でOK（このスコープ内だけで完結させる）
for lr in learning_rates:
    model = NeuralNetwork()
    loss_list = []

    for epoch in range(BASE_EPOCHS):
        y = model.forward(x_train)
        loss = Objective.cross_entropy(y, t_train)
        loss_list.append(loss)
        model.backward(x_train, y, t_train, lr) # ループのlrを使用
        
    pred = np.argmax(y, axis=1)
    ans = np.argmax(t_train, axis=1)
    acc = np.mean(pred == ans)
    print(f"lr: {lr} -> Final Train Accuracy: {acc:.4f}")
    plt.plot(loss_list, label=f"lr={lr}")

plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Learning Rate Comparison")
plt.grid(True)
plt.legend()
plt.show()

# ===================================================
# 実験3：エポック数の比較
# ===================================================
print("\n--- 実験3: エポック数の比較 ---")
epoch_list = [10, 50, 100, 200]

for max_epochs in epoch_list:
    model = NeuralNetwork()
    loss_list = []

    for epoch in range(max_epochs):
        y = model.forward(x_train)
        loss = Objective.cross_entropy(y, t_train)
        loss_list.append(loss)
        # ここで基本の学習率（BASE_LR）を確実に使う！
        model.backward(x_train, y, t_train, BASE_LR)
        
    pred = np.argmax(y, axis=1)
    ans = np.argmax(t_train, axis=1)
    acc = np.mean(pred == ans)
    print(f"Total Epochs: {max_epochs} -> Final Train Accuracy: {acc:.4f}")

    plt.figure(figsize=(6, 4))
    plt.plot(loss_list, label=f"Loss (Total Epochs={max_epochs})", color="blue")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title(f"Training Loss for {max_epochs} Epochs")
    plt.grid(True)
    plt.legend()
    plt.show()

# ===================================================
# 実験4：中間層の比較
# ===================================================
print("\n--- 実験4: 中間層の比較 ---")
hidden_sizes = [32, 64, 128, 256]
plt.figure(figsize=(8, 5))

for h_size in hidden_sizes:
    model = NeuralNetwork(hidden_size=h_size)
    loss_list = []

    for epoch in range(BASE_EPOCHS):
        y = model.forward(x_train)
        loss = Objective.cross_entropy(y, t_train)
        loss_list.append(loss)
        # 基本の学習率（BASE_LR）を使用
        model.backward(x_train, y, t_train, BASE_LR)
        
    pred = np.argmax(y, axis=1)
    ans = np.argmax(t_train, axis=1)
    acc = np.mean(pred == ans)
    print(f"Hidden Size: {h_size} -> Final Train Accuracy: {acc:.4f}")
    plt.plot(loss_list, label=f"hidden={h_size}")

plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Hidden Size Comparison")
plt.grid(True)
plt.legend()
plt.show()

# ===================================================
# 実験5：初期値倍率の比較
# ===================================================
print("\n--- 実験5: 初期値倍率の比較 ---")
weight_scales = [0.01, 0.05, 0.10, 0.25]
plt.figure(figsize=(8, 5))

for scale in weight_scales:
    model = NeuralNetwork(init_scale=scale)
    loss_list = []

    for epoch in range(BASE_EPOCHS):
        y = model.forward(x_train)
        loss = Objective.cross_entropy(y, t_train)
        loss_list.append(loss)
        # 基本の学習率（BASE_LR）を使用
        model.backward(x_train, y, t_train, BASE_LR)
        
    pred = np.argmax(y, axis=1)
    ans = np.argmax(t_train, axis=1)
    acc = np.mean(pred == ans)
    print(f"Scale: {scale} -> Final Train Accuracy: {acc:.4f}")
    plt.plot(loss_list, label=f"scale={scale}")

plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Weight Scale Comparison")
plt.grid(True)
plt.legend()
plt.show()
