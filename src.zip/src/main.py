from dataset import  MNISTLoader
import matplotlib.pyplot as plt
from model import NeuralNetwork
import numpy as np

#活性化関数の比較
epochs=100

loader = MNISTLoader()
model = NeuralNetwork()

x_train, t_train, x_test, t_test = loader.load_data()


loss_list = []

for epoch in range(epochs):

    y = model.forward(x_train)

    loss = model.cross_entropy(
        y,
        t_train
    )

    loss_list.append(loss)

    model.backward(
        x_train,
        y,
        t_train,
        lr
    )
pred = np.argmax(y, axis=1)
ans = np.argmax(t_train, axis=1)

acc = np.mean(pred == ans)

print(acc)
plt.plot(
        loss_list,
        label=f"lr={lr}"
        )
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("ReLU")
plt.grid()
plt.legend()
plt.show()