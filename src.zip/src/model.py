import numpy as np
def sigmoid(x):
    return 1/(1+np.exp(-x))
def sigmoid_grad(x):
    return sigmoid(x)*(1-sigmoid(x))

def softplas(x):
    return np.log(1+np.exp(x))

def ReLU(x):
    return np.maximum(0,x)


def ReLU_grad(x):
    return np.where(x > 0, 1.0, 0.0)

def softmax(x):

    x = x - np.max(x, axis=1, keepdims=True)

    exp_x = np.exp(x)

    return exp_x / np.sum(
        exp_x,
        axis=1,
        keepdims=True
    )
def cross_entropy(y, t):

    delta = 1e-7

    return -np.mean(
        np.sum(
            t * np.log(y + delta),
            axis=1
        )
    )
class NeuralNetwork:

    def __init__(
        self,
        input_size=784,#入力層
        hidden_size=64,#中間層
        output_size=10,#出力層
        activation="sigmoid",#
        weight_init="normal"
    ):

        self.activation_name = activation

        if weight_init == "normal":

            self.W1 = np.random.randn(
                input_size,
                hidden_size
            ) *0.25

            self.W2 = np.random.randn(
                hidden_size,
                output_size
            ) *0.25

        self.b1 = np.zeros((1, hidden_size))
        self.b2 = np.zeros((1, output_size))

    def forward(self,x):
       
       self.z1=x@ self.W1 +self.b1
       self.a1=ReLU(self.z1)

       self.z2=self.a1@ self.W2 +self.b2
       self.a2=softmax(self.z2)
       return self.a2
    
    def backward(self, x, y, t, lr):

     N = x.shape[0]#平均損失

     delta2 = y - t

     dw2 = self.a1.T @ delta2 / N
     db2 = np.sum(delta2, axis=0, keepdims=True) / N

     delta1 = (delta2 @ self.W2.T) * ReLU_grad(self.z1)

     dw1 = x.T @ delta1 / N
     db1 = np.sum(delta1, axis=0, keepdims=True) / N

     self.W1 -= lr * dw1
     self.b1 -= lr * db1

     self.W2 -= lr * dw2
     self.b2 -= lr * db2

